---
firstpage:
lastpage:
---

## BabyAI Environments

```{raw} html
   :file: list.html
```

```{toctree}
:hidden:
:caption: BabyAI Environments

GoToRedBallGrey
GoToRedBall
GoToRedBallNoDists
GoToObj
GoToLocal
GoTo
GoToImpUnlock
GoToSeq
GoToRedBlueBall
GoToDoor
GoToObjDoor
Open
OpenRedDoor
OpenDoor
OpenTwoDoors
OpenDoorsOrder
Pickup
UnblockPickup
PickupLoc
PickupDist
PickupAbove
PutNextLocal
PutNext
Unlock
UnlockLocal
KeyInBox
UnlockPickup
BlockedUnlockPickup
UnlockToUnlock
ActionObjDoor
FindObjS5
KeyCorridor
OneRoomS8
MoveTwoAcross
Synth
SynthLoc
SynthSeq
MiniBossLevel
BossLevel
BossLevelNoUnlock

```
